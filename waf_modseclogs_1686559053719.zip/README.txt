Content
Sources: [waf_modseclogs]
Parsers: [waf_modseclogs]

Reference
Functions: [Geolocation]
Fields: [actn, actntype, cityclnt, clnthostip, continentclnt, continentcodeclnt, countryclnt, countrycodeclnt, domainsrvr, geolocclnt, mbody, msg, prrulesid, regionclnt, regioncodeclnt, reqprotruleids, srvrhostname, time, uri, usrag]
